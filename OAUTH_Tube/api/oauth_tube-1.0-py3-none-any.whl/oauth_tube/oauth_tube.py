import datetime
import json
import os
import signal
import ssl
import sys
import threading
from datetime import datetime
from http.server import SimpleHTTPRequestHandler, HTTPServer
import colorama


def is_venv() -> str:
    if hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix):
        # Retorna o diretório de bibliotecas do ambiente virtual
        return os.path.join(os.path.dirname(os.path.abspath(sys.executable)), 'Lib',
                            'site-packages') if os.name == 'nt' else os.path.join(
            os.path.dirname(os.path.abspath(sys.executable)), 'lib',
            'python{0.major}.{0.minor}'.format(sys.version_info), 'site-packages')
    else:
        # Retorna o diretório de bibliotecas globais do Python global
        return os.path.join(os.path.dirname(os.path.abspath(sys.executable)), 'Lib',
                            'site-packages') if os.name == 'nt' else os.path.join(
            os.path.dirname(os.path.abspath(sys.executable)), 'lib',
            'python{0.major}.{0.minor}'.format(sys.version_info), 'site-packages')


colorama.init(autoreset=True)
current_dir = os.path.dirname(os.path.abspath(__file__))
# Cria o caminho para o diretório de cache
cache_dir = os.path.join(current_dir, '__auth__')
CACHE = os.path.abspath(cache_dir)
os.makedirs(cache_dir, exist_ok=True)


def format_cookies(cookies):
    """
    Formata os cookies em um cabeçalho HTTP.

    :param cookies: Lista de dicionários com os cookies
    :return: String formatada dos cookies
    """
    cookie_header = []
    for cookie in cookies:
        if 'value' in cookie and cookie['value']:
            cookie_header.append(f"{cookie['name']}={cookie['value']}")
    return "; ".join(cookie_header)


def save_file(filename, content):
    try:
        # Cria o diretório de cache se não existir
        os.makedirs(cache_dir, exist_ok=True)

        # Caminho completo para o arquivo
        file_path = os.path.join(cache_dir, filename)

        # Verifica se o arquivo existe e compara o conteúdo
        if os.path.exists(file_path):
            with open(file_path, 'r') as file:
                existing_content = file.read()
                if existing_content == content:
                    return  # Sai da função se o conteúdo for igual

        # Atualiza o conteúdo do arquivo
        with open(file_path, 'w') as file:
            file.write(content)
            current_time = datetime.now().strftime("%d-%m-%y %H:%M:%S")
            print(
                f"[{colorama.Fore.CYAN}{current_time}{colorama.Style.RESET_ALL}] Cache saved to {colorama.Fore.GREEN}{os.path.abspath(file_path)}{colorama.Style.RESET_ALL}")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


def headers_parser(data: dict, self=None):
    tab_id = data.get('tab_id')
    url = data.get('url')
    headers = data.get('headers')
    cookies = data.get('cookies')
    response = data.get('body')
    action = data.get('action', None)
    if action:
        if action == 'reload_or_create':
            # Envia resposta
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()

            response = {'sucess': True, 'action': 'reload'}
            self.wfile.write(json.dumps(response).encode('utf-8'))

    if headers:
        for d in headers:
            if cookies:
                ckk = format_cookies(cookies)
                save_file(filename='.cookies', content=ckk)
            auth = d.get("name", None)
            if auth:
                if auth == 'Authorization':
                    value_auth = d['value']
                    save_file(filename='.auth', content=value_auth)
                    save_file(filename='.endpoint', content=url)
                    # Envia resposta
                    self.send_response(200)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()

                    response = {'message': 'Dados recebidos com sucesso'}
                    self.wfile.write(json.dumps(response).encode('utf-8'))


def generate_erros(erro_code, msg: str = 'A página que você está procurando não existe ou foi movida.'):
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ERRO {erro_code}</title>
    <style>
        /* Reset básico de margin e padding */
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        /* Estilo para o body */
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(135deg, #2c3e50, #34495e);
            color: white;
            overflow: hidden;
            margin: 0;
        }}

        /* Container para centralizar o conteúdo */
        .container {{
            text-align: center;
            transform: translateY(-50%);
        }}

        /* Estilo do título */
        h1 {{
            font-size: 200px;
            font-weight: bold;
            margin-bottom: 20px;
            color: #ecf0f1;
            text-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            animation: fadeIn 1.5s ease-in-out, bounce 1s ease-in-out infinite;
        }}

        /* Animação para fade-in */
        @keyframes fadeIn {{
            from {{
                opacity: 0;
                transform: translateY(30px);
            }}
            to {{
                opacity: 1;
                transform: translateY(0);
            }}
        }}

        /* Animação para bounce */
        @keyframes bounce {{
            0%, 100% {{
                transform: translateY(0);
            }}
            50% {{
                transform: translateY(-20px);
            }}
        }}

        /* Estilo para a mensagem de erro */
        .message {{
            font-size: 20px;
            color: #bdc3c7;
            margin-top: 10px;
            opacity: 0;
            animation: fadeIn 2s ease-out forwards;
        }}

        /* Botão estilizado */
        .back-button {{
            margin-top: 30px;
            padding: 12px 25px;
            font-size: 16px;
            color: white;
            background-color: #e74c3c;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-transform: uppercase;
            letter-spacing: 1px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }}

        .back-button:hover {{
            background-color: #c0392b;
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.2);
        }}

        /* Animação de entrada para o botão */
        .back-button {{
            animation: fadeIn 3s ease-in-out forwards;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>{erro_code}</h1>
        <div class="message">{msg}</div>
    </div>
</body>
</html>
"""
    return html.encode('utf-8')


# Classe para lidar com requisições HTTP
class CORSRequestHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def do_OPTIONS(self):
        # Responde a requisições OPTIONS com cabeçalhos CORS
        self.send_response(200, "ok")
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_POST(self):
        # Processa requisições POST com suporte a CORS
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)

        # Converte os dados de JSON para um dicionário Python
        data = json.loads(post_data)
        headers_parser(data=data, self=self)

    def do_GET(self):

        # Sobrescreve o comportamento de GET para desativar a listagem de diretórios
        response = {'message': 'Olá usuário! estou na ativa! ;)',
                    'StatusApi': 'Api funcionando normalmente!'
                    }
        if self.path == '/api/status':
            # Retorna um erro 403 para acesso direto a diretórios
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(response).encode('utf-8'))
        else:
            # Executa o comportamento padrão para arquivos
            self.list_directory(self.path)

    def do_HEAD(self):
        pass

    def log_message(self, format, *args):
        pass

    def send_header(self, keyword, value):
        # Envia os cabeçalhos de segurança
        super().send_header(keyword, value)
        if keyword == "Content-Type" and value == "application/json":
            self.send_header("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Content-Security-Policy",
                             "default-src 'self'; script-src 'self'; object-src 'none'; style-src 'self'")
            self.send_header("Referrer-Policy", "no-referrer-when-downgrade")
            self.send_header("Permissions-Policy", "geolocation=(), microphone=(), camera=()")

    def list_directory(self, path):
        # Evitar a listagem de diretórios
        self.send_response(403)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(generate_erros(erro_code=403))
        return


def run_server():
    server_address = ('127.0.0.1', 4474)

    def handler(*args, **kwargs) -> any:
        CORSRequestHandler(*args, **kwargs)

    httpd = HTTPServer(server_address, handler)
    httpd.serve_forever()


def main():
    # Inicia o servidor em uma thread separada
    server_thread = threading.Thread(target=run_server)
    server_thread.start()
    print(f"{colorama.Fore.LIGHTGREEN_EX}\t-> Online!{colorama.Style.RESET_ALL}\n")
    while True:
        cmd = input(f"{colorama.Fore.LIGHTYELLOW_EX}OUATH-TUBE{colorama.Style.RESET_ALL}:: ")
        if cmd.lower() == "stop":
            print(f"{colorama.Fore.LIGHTRED_EX}Stoped!{colorama.Style.RESET_ALL}")
            os.kill(os.getpid(), signal.SIGTERM)
        elif cmd.lower() == 'clear':
            # Limpa a tela do terminal
            os.system('cls' if os.name == 'nt' else 'clear')
            print(f"{colorama.Fore.LIGHTGREEN_EX}\t-> Online!{colorama.Style.RESET_ALL}\n")
        elif cmd.lower() == 'help':
            help_me()


def help_me():
    cmds = f"""{colorama.Fore.CYAN}Comandos Disponíveis:{colorama.Style.RESET_ALL}

    {colorama.Fore.LIGHTGREEN_EX}init{colorama.Style.RESET_ALL}\t-\t{colorama.Fore.YELLOW}inicia o servidor
{colorama.Style.RESET_ALL}
    {colorama.Fore.LIGHTGREEN_EX}stop{colorama.Style.RESET_ALL}\t-\t{colorama.Fore.YELLOW}para o servidor
{colorama.Style.RESET_ALL}
    {colorama.Fore.LIGHTGREEN_EX}help{colorama.Style.RESET_ALL}\t-\t{colorama.Fore.YELLOW}exibe os comandos disponíveis
{colorama.Style.RESET_ALL}
    """
    print(cmds)


def initiation():
    try:
        args = sys.argv[1:]
        if "init" in args:
            main()
        elif "help" in args:
            help_me()
        else:
            help_me()
    except KeyboardInterrupt:
        os.kill(os.getpid(), signal.SIGTERM)
    except Exception as e:
        print(f"ERRO: {e}")
        os.kill(os.getpid(), signal.SIGTERM)


initiation()
